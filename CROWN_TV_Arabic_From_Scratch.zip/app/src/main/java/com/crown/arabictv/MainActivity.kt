package com.crown.arabictv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        window.decorView.setBackgroundColor(Color.rgb(8, 13, 24))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 32, 48, 32)
            setBackgroundColor(Color.rgb(8, 13, 24))
        }
        root.addView(TextView(this).apply {
            text = "♛  CROWN TV"
            textSize = 38f
            setTextColor(Color.rgb(85, 214, 190))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "شاشة انتظار عربية أنيقة للتلفاز\nالساعة • مواقيت الصلاة • الطقس • ريال مدريد"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 28)
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "فتح إعدادات شاشة الانتظار"
            textSize = 20f
            isFocusable = true
            setOnClickListener {
                runCatching { startActivity(Intent(Settings.ACTION_DREAM_SETTINGS)) }
                    .onFailure { runCatching { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } }
            }
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "إذا ظهر CROWN TV ضمن الخيارات، اختره كشاشة انتظار. قد لا تدعم بعض أجهزة التلفاز هذه الميزة."
            textSize = 17f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }
}
