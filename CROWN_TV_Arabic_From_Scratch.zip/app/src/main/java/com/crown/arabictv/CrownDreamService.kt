package com.crown.arabictv

import android.service.dreams.DreamService
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

class CrownDreamService : DreamService() {
    private val worker = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(18, 27, 43)
    private val accent = Color.rgb(85, 214, 190)
    private val white = Color.rgb(239, 243, 249)
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var prayer: TextView
    private lateinit var weather: TextView
    private lateinit var match: TextView
    private lateinit var status: TextView
    @Volatile private var running = false
    private val tz = TimeZone.getTimeZone("Asia/Damascus")

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = false
        isFullscreen = true
        window?.decorView?.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LOW_PROFILE)
        setContentView(makeLayout())
    }

    override fun onDreamingStarted() {
        super.onDreamingStarted()
        running = true
        updateClock()
        refreshData()
    }

    override fun onDreamingStopped() {
        running = false
        mainHandler.removeCallbacksAndMessages(null)
        super.onDreamingStopped()
    }

    override fun onDestroy() {
        running = false
        mainHandler.removeCallbacksAndMessages(null)
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun makeLayout(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(46, 26, 46, 26)
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "♛  CROWN TV  •  شاشة الانتظار"
            textSize = 23f
            setTextColor(accent)
            gravity = Gravity.CENTER
        }, lp(-1, -2))
        clock = TextView(this).apply {
            text = "--:--"
            textSize = 82f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(white)
            gravity = Gravity.CENTER
        }
        root.addView(clock, lp(-1, -2))
        date = TextView(this).apply {
            text = "الصور، دير الزور • سوريا"
            textSize = 20f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(date, lp(-1, -2))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        prayer = card("مواقيت الصلاة", "جارٍ التحميل…")
        weather = card("الطقس في الصور", "جارٍ التحميل…")
        match = card("ريال مدريد", "جارٍ تحميل المباريات…")
        row.addView(prayer, weighted()); row.addView(weather, weighted()); row.addView(match, weighted())
        root.addView(row, lp(-1, 250))
        status = TextView(this).apply {
            text = "تُحدّث البيانات عند توفر الإنترنت"
            textSize = 14f
            setTextColor(Color.rgb(133, 149, 171))
            gravity = Gravity.CENTER
        }
        root.addView(status, lp(-1, -2))
        return root
    }

    private fun card(title: String, initial: String) = TextView(this).apply {
        text = "$title\n\n$initial"; textSize = 19f; setTextColor(white); gravity = Gravity.CENTER
        setPadding(14, 16, 14, 16); setBackgroundColor(panel); isSingleLine = false
    }

    private fun updateClock() {
        if (!running) return
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale("ar")).apply { timeZone = tz }.format(now)
        date.text = "الصور، دير الزور • " + SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")).apply { timeZone = tz }.format(now)
        mainHandler.postDelayed({ updateClock() }, 30_000L)
    }

    private fun refreshData() {
        if (!running) return
        worker.execute {
            val p = runCatching { getPrayerTimes() }.getOrElse { "تعذر جلب المواقيت\nتحقق من الإنترنت" }
            val w = runCatching { getWeather() }.getOrElse { "تعذر جلب الطقس\nتحقق من الإنترنت" }
            val m = runCatching { getMadridFixture() }.getOrElse { "تعذر جلب جدول المباريات" }
            mainHandler.post {
                if (!running) return@post
                prayer.text = "مواقيت الصلاة\n\n$p"
                weather.text = "الطقس في الصور\n\n$w"
                match.text = "ريال مدريد\n\n$m"
                status.text = "آخر تحديث: " + SimpleDateFormat("HH:mm", Locale("ar")).apply { timeZone = tz }.format(Date())
                mainHandler.postDelayed({ if (running) refreshData() }, 30 * 60 * 1000L)
            }
        }
    }

    private fun getPrayerTimes(): String {
        val url = URL("https://api.aladhan.com/v1/timings?latitude=35.50458&longitude=40.65649&method=3")
        val t = JSONObject(readUrl(url)).getJSONObject("data").getJSONObject("timings")
        return "الفجر ${clean(t.getString("Fajr"))}\nالظهر ${clean(t.getString("Dhuhr"))}\nالعصر ${clean(t.getString("Asr"))}\nالمغرب ${clean(t.getString("Maghrib"))}\nالعشاء ${clean(t.getString("Isha"))}"
    }

    private fun getWeather(): String {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=35.50458&longitude=40.65649&current=temperature_2m,relative_humidity_2m,weather_code&timezone=Asia%2FDamascus")
        val c = JSONObject(readUrl(url)).getJSONObject("current")
        return "${c.getDouble("temperature_2m").toInt()}°C • ${weatherLabel(c.getInt("weather_code"))}\nالرطوبة ${c.getInt("relative_humidity_2m")}%"
    }

    private fun getMadridFixture(): String {
        val root = JSONObject(readUrl(URL("https://site.api.espn.com/apis/site/v2/sports/soccer/esp.1/teams/86/schedule")))
        val events = root.optJSONArray("events") ?: return "لم تُعلن المباراة القادمة"
        val now = System.currentTimeMillis()
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            val millis = runCatching { java.time.Instant.parse(event.optString("date")).toEpochMilli() }.getOrDefault(0L)
            if (millis > now) return event.optString("name", "المباراة القادمة") + "\n" + SimpleDateFormat("EEE d MMM • HH:mm", Locale("ar")).apply { timeZone = tz }.format(Date(millis))
        }
        return "لا توجد مباراة قادمة في الجدول المتاح"
    }

    private fun readUrl(url: URL): String {
        val conn = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000; requestMethod = "GET"; setRequestProperty("User-Agent", "CROWN-TV-Arabic/1.0") }
        return try { conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() } } finally { conn.disconnect() }
    }
    private fun clean(value: String) = value.substringBefore(" ").trim()
    private fun weatherLabel(code: Int): String = when (code) {
        0 -> "صحو"; 1, 2 -> "غائم جزئياً"; 3 -> "غائم"; 45, 48 -> "ضباب"
        51, 53, 55, 56, 57 -> "رذاذ"; 61, 63, 65, 66, 67, 80, 81, 82 -> "أمطار"
        71, 73, 75, 77, 85, 86 -> "ثلوج"; 95, 96, 99 -> "عواصف رعدية"; else -> "حالة جوية متغيرة"
    }
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun weighted() = LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = 9; marginEnd = 9 }
}
